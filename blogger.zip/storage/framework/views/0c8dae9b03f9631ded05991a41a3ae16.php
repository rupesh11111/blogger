
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mt-5">
                    <div class="card-header">
                        <h4>Create Blog</h4>
                    </div>
                    <div class="card-body">
                        <form id="ajaxFormSubmit" data-action=<?php echo e($action); ?> data-redirect=<?php echo e($redirect); ?>>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="title">Title</label>
                                <input type="text" class="form-control" name="title" placeholder="Enter title">
                            </div>
                            <div class="form-group">
                                <label for="image">Image</label>
                                <input type="file" class="form-control" name="image" placeholder="Enter Image">
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea class="form-control" name="description" placeholder="Enter Description"></textarea>
                            </div>
                            <a type="button" class="btn btn-primary" href="<?php echo e(url("dashboard")); ?>">Back</a>
                            <button type="submit" class="btn btn-primary">Create</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        rules = {
            title: {
                required: true
            },
            description: {
                required: true
            },
        }

        messages = {};
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myproject\resources\views/blogCreate.blade.php ENDPATH**/ ?>