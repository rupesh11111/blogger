
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mt-5">
                    <div class="card-header">
                        <h4>Blogger Registration</h4>
                    </div>
                    <div class="card-body">
                        <form id="ajaxFormSubmit" data-action=<?php echo e($action); ?> data-redirect=<?php echo e($redirect); ?>>
                            <?php echo csrf_field(); ?>
                            <div class="form-group"  >
                                <label for="name">Name</label>
                                <input type="text" class="form-control" name="name" placeholder="Enter name">
                            </div>
                            <div class="form-group"  >
                                <label for="email">Email</label>
                                <input type="email" class="form-control" name="email" placeholder="Enter email">
                            </div>
                            <div class="form-group"  >
                                <label for="phone">Phone</label>
                                <input type="text" class="form-control" name="phone" placeholder="Enter Phone">
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" name="password" placeholder="Enter password">
                            </div>
                            <div class="form-group">
                                <label for="password_confirmation">Confirm Password</label>
                                <input type="password" class="form-control" name="password_confirmation" placeholder="Enter Confirmation password">
                            </div>
                            <button type="submit" class="btn btn-primary">Signup</button>
                        </form>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                    </div>
                
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        rules = {
            name :{
                required: true,   
            }
            email: {
                required: true,
                email:true
            },
            password: {
                required: true,
                min:6
            },
            password_confirmation: {
                required: true,
                min :6
            },
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\myproject\resources\views/signup.blade.php ENDPATH**/ ?>