@extends('layout')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-12 text-center pt-5">
                <h1 class="display-one mt-5">PHP Laravel Project - CRUD</h1>
                <p>Welcome to the PHP Laravel project demo for beginners</p>
                <br>
                <a href="product" class="btn btn-outline-primary">Show Products</a>
            </div>
        </div>
    </div>
@endsection
